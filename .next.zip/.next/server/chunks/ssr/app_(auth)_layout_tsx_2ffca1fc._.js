module.exports=[12498,a=>{"use strict";a.s(["default",()=>c]);var b=a.i(7997);let c=({children:a})=>(0,b.jsx)("div",{className:"flex h-full justify-center items-center",children:a})}];

//# sourceMappingURL=app_%28auth%29_layout_tsx_2ffca1fc._.js.map
var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__ca3a8df6._.js")
R.c("server/chunks/node_modules_next_d44470fc._.js")
R.m(43433)
R.m(59061)
module.exports=R.m(59061).exports

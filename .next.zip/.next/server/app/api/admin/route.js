var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/route.js")
R.c("server/chunks/[root-of-the-server]__cff9a264._.js")
R.c("server/chunks/node_modules_next_d44470fc._.js")
R.m(45084)
R.m(62569)
module.exports=R.m(62569).exports

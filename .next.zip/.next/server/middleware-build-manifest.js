globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/49a89cc22964b096.js",
      "static/chunks/turbopack-963235af1ffc9b2d.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/49a89cc22964b096.js",
      "static/chunks/turbopack-9c3953f460fe9922.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/e1bcd3a77102413c.js",
    "static/chunks/639cda399f61da4f.js",
    "static/chunks/ab12c98d27106880.js",
    "static/chunks/0656f51f27ce398d.js",
    "static/chunks/4a4074717300b14a.js",
    "static/chunks/50f9503f16d44625.js",
    "static/chunks/turbopack-0050c72c34b69a98.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];
globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/0d6fc839a0afd8b7.js",
      "static/chunks/turbopack-18d24186d36283ef.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/0d6fc839a0afd8b7.js",
      "static/chunks/turbopack-74b824492d4ccc0e.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/e1bcd3a77102413c.js",
    "static/chunks/00be4f980179e725.js",
    "static/chunks/0cc6e9a29ef74417.js",
    "static/chunks/0656f51f27ce398d.js",
    "static/chunks/4a4074717300b14a.js",
    "static/chunks/50f9503f16d44625.js",
    "static/chunks/turbopack-73dc3ddf2d92f5b9.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];
globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/9084bb1672336f6a.js",
      "static/chunks/turbopack-4214aed2c966a372.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/9084bb1672336f6a.js",
      "static/chunks/turbopack-0035dc2068374846.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/e1bcd3a77102413c.js",
    "static/chunks/639cda399f61da4f.js",
    "static/chunks/ab12c98d27106880.js",
    "static/chunks/0656f51f27ce398d.js",
    "static/chunks/4a4074717300b14a.js",
    "static/chunks/50f9503f16d44625.js",
    "static/chunks/turbopack-0050c72c34b69a98.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];
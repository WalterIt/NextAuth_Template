__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/9084bb1672336f6a.js",
  "static/chunks/turbopack-0035dc2068374846.js"
])

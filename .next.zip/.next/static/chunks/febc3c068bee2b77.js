__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/0d6fc839a0afd8b7.js",
  "static/chunks/turbopack-18d24186d36283ef.js"
])

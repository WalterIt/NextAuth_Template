__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/49a89cc22964b096.js",
  "static/chunks/turbopack-963235af1ffc9b2d.js"
])

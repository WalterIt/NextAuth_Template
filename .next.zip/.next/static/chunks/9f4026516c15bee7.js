__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/9084bb1672336f6a.js",
  "static/chunks/turbopack-4214aed2c966a372.js"
])

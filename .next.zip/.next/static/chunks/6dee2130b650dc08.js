__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/49a89cc22964b096.js",
  "static/chunks/turbopack-9c3953f460fe9922.js"
])

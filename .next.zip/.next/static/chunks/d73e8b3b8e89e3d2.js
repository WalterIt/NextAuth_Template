__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/c444e5caaa5f6c69.js",
  "static/chunks/turbopack-8db9b4a97becaaf7.js"
])

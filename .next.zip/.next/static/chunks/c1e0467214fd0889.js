__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/0d6fc839a0afd8b7.js",
  "static/chunks/turbopack-74b824492d4ccc0e.js"
])
